package Lab13;

public class ConcreteObserverB extends Observer {
	public void update()
	{
	
	}

}
