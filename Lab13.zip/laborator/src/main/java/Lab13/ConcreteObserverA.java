package Lab13;

public class ConcreteObserverA extends Observer {

	public void update()
	{
	
	}
}
