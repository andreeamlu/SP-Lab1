package Lab13;

public class Observer {
	public void update()
	{
	
	}

}
