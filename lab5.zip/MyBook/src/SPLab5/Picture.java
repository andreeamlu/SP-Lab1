package SPLab5;

public interface Picture {

}
