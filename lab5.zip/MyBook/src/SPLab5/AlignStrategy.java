package SPLab5;

public interface AlignStrategy {
	void render(Paragraph p);

}
