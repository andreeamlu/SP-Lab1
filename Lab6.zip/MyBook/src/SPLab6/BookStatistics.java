package SPLab6;

public class BookStatistics implements Visitor {

	private int nrimagini;
	private int nrtabele;
	private int nrparagrafe;

	@Override
	public void visitBook(Book a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitSection(Section a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitTableOfContents(TableOfContents a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visitParagraph(Paragraph a) {
		this.nrparagrafe = this.nrparagrafe + 1;
		// TODO Auto-generated method stub

	}

	@Override
	public void visitImageProxy(ImageProxy a) {
		this.nrimagini = this.nrimagini + 1;
		// TODO Auto-generated method stub

	}

	@Override
	public void visitImage(Image a) {
		this.nrimagini = this.nrimagini + 1;
		// TODO Auto-generated method stub

	}

	@Override
	public void visitTable(Table a) {
		this.nrtabele = this.nrtabele + 1;
		// TODO Auto-generated method stub

	}

	public void printStatistics() {
		System.out.println("Book Statistics:");
		System.out.println("*** Number of images: " + this.nrimagini);
		System.out.println("*** Number of tables: " + this.nrtabele);
		System.out.println("*** Number of paragraphs: " + this.nrparagrafe);

	}

}
