package SPLab6;

public interface Picture {

}
