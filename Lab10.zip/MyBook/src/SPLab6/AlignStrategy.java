package SPLab6;

public interface AlignStrategy {
	void render(Paragraph p);

}
